jQuery(document).ready(function ($) {
    "use strict";

    /* Write your custom JS below */

});
